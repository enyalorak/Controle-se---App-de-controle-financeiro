import 'package:flutter/material.dart';

class FinanceHomePage extends StatefulWidget {
  const FinanceHomePage({super.key});

  @override
  State<FinanceHomePage> createState() => _FinanceHomePageState();
}

class _FinanceHomePageState extends State<FinanceHomePage> {
  double totalReceitas = 0.0;
  double totalDespesas = 0.0;

  final List<String> meses = [
    'Janeiro',
    'Fevereiro',
    'Março',
    'Abril',
    'Maio',
    'Junho',
    'Julho',
    'Agosto',
    'Setembro',
    'Outubro',
    'Novembro',
    'Dezembro',
  ];

  // Para armazenar transações (opcional, aqui só para mostrar últimas transações)
  final List<Map<String, dynamic>> transacoes = [];

  double get saldo => totalReceitas - totalDespesas;

  void _confirmarLimpar() {
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text('Limpar tudo?'),
          content: const Text(
            'Deseja apagar todas as receitas e despesas? Esta ação não pode ser desfeita.',
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(context).pop(),
              child: const Text('Cancelar'),
            ),
            ElevatedButton(
              onPressed: () {
                setState(() {
                  totalReceitas = 0;
                  totalDespesas = 0;
                  transacoes.clear();
                });
                Navigator.of(context).pop();
              },
              child: const Text('Confirmar'),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final now = DateTime.now();
    final mesAtual = meses[now.month - 1];

    return Scaffold(
      appBar: AppBar(
        title: Text('$mesAtual - Finanças Pessoais'),
        actions: [
          IconButton(
            icon: const Icon(Icons.delete_forever),
            onPressed: _confirmarLimpar,
          ),
          IconButton(icon: const Icon(Icons.account_circle), onPressed: () {}),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Saldo em contas
            Card(
              elevation: 4,
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'Saldo em contas',
                      style: TextStyle(fontSize: 16, color: Colors.grey),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      'R\$${saldo.toStringAsFixed(2)}',
                      style: const TextStyle(
                        fontSize: 28,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 16),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text(
                              'Receitas',
                              style: TextStyle(
                                fontSize: 14,
                                color: Colors.grey,
                              ),
                            ),
                            Text(
                              'R\$${totalReceitas.toStringAsFixed(2)}',
                              style: TextStyle(
                                fontSize: 18,
                                color: Colors.green[700],
                              ),
                            ),
                          ],
                        ),
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text(
                              'Despesas',
                              style: TextStyle(
                                fontSize: 14,
                                color: Colors.grey,
                              ),
                            ),
                            Text(
                              'R\$${totalDespesas.toStringAsFixed(2)}',
                              style: TextStyle(
                                fontSize: 18,
                                color: Colors.red[700],
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),

            const SizedBox(height: 20),

            // Despesas por categoria
            const Text(
              'Despesas por categoria',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 10),
            SizedBox(
              height: 100,
              child: ListView(
                scrollDirection: Axis.horizontal,
                children: [
                  _buildCategoryItem(Icons.school, 'Educação', Colors.blue),
                  _buildCategoryItem(Icons.home, 'Casa', Colors.orange),
                  _buildCategoryItem(
                    Icons.fastfood,
                    'Alimentação',
                    Colors.green,
                  ),
                  _buildCategoryItem(Icons.pool, 'Lazer', Colors.grey),
                  _buildCategoryItem(Icons.tv_sharp, 'Streaming', Colors.blue),
                ],
              ),
            ),

            const SizedBox(height: 20),

            // Cartões de crédito
            const Text(
              'Cartões de crédito',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 10),
            Card(
              child: Padding(
                padding: const EdgeInsets.all(12.0),
                child: Column(
                  children: [
                    const ListTile(
                      title: Text('Nubank'),
                      subtitle: Text('Vence amanhã'),
                      trailing: Text(
                        'R\$30,00',
                        style: TextStyle(
                          color: Colors.red,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                    const Divider(),
                    ListTile(
                      title: const Text('Caixa'),
                      subtitle: const Text('Vence amanhã'),
                      trailing: Text(
                        'R\$0,00',
                        style: TextStyle(
                          color: Colors.green,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),

            const SizedBox(height: 20),

            // Últimas transações
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text(
                  'Últimas transações',
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                ),
                TextButton(onPressed: () {}, child: const Text('Ver todas')),
              ],
            ),

            ...transacoes.reversed
                .take(5)
                .map(
                  (t) => ListTile(
                    leading: Icon(
                      t['tipo'] == 'receita'
                          ? Icons.arrow_downward
                          : Icons.arrow_upward,
                      color: t['tipo'] == 'receita' ? Colors.green : Colors.red,
                    ),
                    title: Text(t['descricao']),
                    trailing: Text(
                      'R\$${t['valor'].toStringAsFixed(2)}',
                      style: TextStyle(
                        color: t['tipo'] == 'receita'
                            ? Colors.green
                            : Colors.red,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                )
                .toList(),
          ],
        ),
      ),

      floatingActionButton: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          FloatingActionButton.extended(
            heroTag: 'addReceita',
            onPressed: () => _mostrarDialogo(context, 'receita'),
            label: const Text('Adicionar Receita'),
            icon: const Icon(Icons.add_circle_outline),
            backgroundColor: Colors.green,
          ),
          const SizedBox(height: 10),
          FloatingActionButton.extended(
            heroTag: 'addDespesa',
            onPressed: () => _mostrarDialogo(context, 'despesa'),
            label: const Text('Adicionar Despesa'),
            icon: const Icon(Icons.remove_circle_outline),
            backgroundColor: Colors.red,
          ),
        ],
      ),
      bottomNavigationBar: BottomNavigationBar(
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.home), label: 'Início'),
          BottomNavigationBarItem(
            icon: Icon(Icons.credit_card),
            label: 'Cartões',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.bar_chart),
            label: 'Relatórios',
          ),
          BottomNavigationBarItem(icon: Icon(Icons.settings), label: 'Config'),
        ],
      ),
    );
  }

  Widget _buildCategoryItem(IconData icon, String label, Color color) {
    return Padding(
      padding: const EdgeInsets.only(right: 16.0),
      child: Column(
        children: [
          CircleAvatar(
            backgroundColor: color.withOpacity(0.2),
            radius: 30,
            child: Icon(icon, color: color, size: 30),
          ),
          const SizedBox(height: 8),
          Text(label),
        ],
      ),
    );
  }

  Future<void> _mostrarDialogo(BuildContext context, String tipo) async {
    final TextEditingController valorController = TextEditingController();
    final TextEditingController descricaoController = TextEditingController();

    await showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: Text(
            tipo == 'receita' ? 'Adicionar Receita' : 'Adicionar Despesa',
          ),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: descricaoController,
                decoration: const InputDecoration(labelText: 'Descrição'),
              ),
              TextField(
                controller: valorController,
                keyboardType: const TextInputType.numberWithOptions(
                  decimal: true,
                ),
                decoration: const InputDecoration(
                  labelText: 'Valor (ex: 1500.00)',
                ),
              ),
            ],
          ),
          actions: [
            TextButton(
              child: const Text('Cancelar'),
              onPressed: () => Navigator.of(context).pop(),
            ),
            ElevatedButton(
              child: const Text('Adicionar'),
              onPressed: () {
                final valor = double.tryParse(
                  valorController.text.replaceAll(',', '.'),
                );
                final descricao = descricaoController.text.trim();

                if (valor != null && valor > 0 && descricao.isNotEmpty) {
                  setState(() {
                    if (tipo == 'receita') {
                      totalReceitas += valor;
                    } else {
                      totalDespesas += valor;
                    }
                    transacoes.add({
                      'tipo': tipo,
                      'descricao': descricao,
                      'valor': valor,
                    });
                  });
                  Navigator.of(context).pop();
                } else {
                  // Mostrar erro simples
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(
                      content: Text('Informe um valor válido e descrição'),
                    ),
                  );
                }
              },
            ),
          ],
        );
      },
    );
  }
}
