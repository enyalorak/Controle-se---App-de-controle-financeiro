import 'package:controlese/view/auth_service.dart';
import 'package:controlese/view/finance_page.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  AuthService authService = Get.find();

  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  TextEditingController emailController = TextEditingController();
  TextEditingController passwordController = TextEditingController();

  String? isAValidEmail(value) {
    if (value == null || value.isEmpty) {
      return 'O campo de e-mail não pode estar vazio';
    }
    String pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$';
    RegExp regex = RegExp(pattern);
    if (!regex.hasMatch(value)) {
      return 'Insira um e-mail válido';
    }
    return null;
  }

  String? isAValidPassword(value) {
    if (value == null || value.isEmpty) {
      return 'A senha não pode estar vazia';
    }

    if (value.length < 6) {
      return 'A senha deve conter pelo menos 6 caracteres';
    }

    String pattern = r'^(?=.*[0-9]).+$';
    RegExp regex = RegExp(pattern);
    if (!regex.hasMatch(value)) {
      return 'A senha deve conter pelo menos 1 caractere numérico.';
    }
    return null;
  }

  @override
  Widget build(BuildContext context) {
    return Form(
      key: _formKey,
      child: Scaffold(
        appBar: AppBar(),
        body: Center(
          child: Column(
            children: [
              SizedBox(height: 60),
              Container(
                decoration: BoxDecoration(border: Border.all()),
                width: 300,
                child: TextFormField(
                  controller: emailController,
                  validator: isAValidEmail,
                  decoration: InputDecoration(
                    icon: Icon(Icons.email),
                    label: Text('Email'),
                  ),
                ),
              ),
              Container(
                decoration: BoxDecoration(border: Border.all()),
                width: 300,
                child: TextFormField(
                  controller: passwordController,
                  validator: isAValidPassword,
                  decoration: InputDecoration(
                    icon: Icon(Icons.email),
                    label: Text('Senha'),
                  ),
                ),
              ),
              ElevatedButton(
                onPressed: () async {
                  if (_formKey.currentState?.validate() == true) {
                    String? message = await authService.loginUser(
                      email: emailController.text,
                      password: passwordController.text,
                    );
                    if (message == null) {
                      Get.offAll(FinanceHomePage());
                      Get.snackbar('Sucesso', 'Login efetuado.');
                    } else {
                      Get.snackbar(
                        'ERRO!',
                        message,
                        backgroundColor: Colors.red[50],
                        colorText: Colors.red,
                      );
                    }
                  }
                },
                child: Text('Logar conta'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
