import 'package:firebase_core/firebase_core.dart' show FirebaseOptions;
import 'package:flutter/foundation.dart'
    show defaultTargetPlatform, kIsWeb, TargetPlatform;

class DefaultFirebaseOptions {
  static FirebaseOptions get currentPlatform {
    if (kIsWeb) {
      return web;
    }
    switch (defaultTargetPlatform) {
      case TargetPlatform.android:
        return android;
      case TargetPlatform.iOS:
        return ios;
      case TargetPlatform.macOS:
        throw UnsupportedError(
          'DefaultFirebaseOptions have not been configured for macos - '
          'you can reconfigure this by running the FlutterFire CLI again.',
        );
      case TargetPlatform.windows:
        return windows;
      case TargetPlatform.linux:
        throw UnsupportedError(
          'DefaultFirebaseOptions have not been configured for linux - '
          'you can reconfigure this by running the FlutterFire CLI again.',
        );
      default:
        throw UnsupportedError(
          'DefaultFirebaseOptions are not supported for this platform.',
        );
    }
  }

  // Configuração para Android
  static const FirebaseOptions android = FirebaseOptions(
    apiKey: 'SUA_CHAVE_DE_API_ANDROID',
    appId: '1:SEU_APP_ID:android:SEU_ID_ANDROID',
    messagingSenderId: 'SEU_SENDER_ID',
    projectId: 'SEU_PROJETO_ID',
    storageBucket: 'SEU_BUCKET.appspot.com',
  );

  // Configuração para iOS
  static const FirebaseOptions ios = FirebaseOptions(
    apiKey: 'SUA_CHAVE_DE_API_IOS',
    appId: '1:SEU_APP_ID:ios:SEU_ID_IOS',
    messagingSenderId: 'SEU_SENDER_ID',
    projectId: 'SEU_PROJETO_ID',
    storageBucket: 'SEU_BUCKET.appspot.com',
    iosBundleId: 'SEU_BUNDLE_ID',
    iosClientId: 'SEU_CLIENT_ID_IOS',
  );

  // Configuração para Web
  static const FirebaseOptions web = FirebaseOptions(
    apiKey: 'SUA_CHAVE_DE_API_WEB',
    appId: '1:SEU_APP_ID:web:SEU_ID_WEB',
    messagingSenderId: 'SEU_SENDER_ID',
    projectId: 'SEU_PROJETO_ID',
    authDomain: 'SEU_DOMINIO.firebaseapp.com',
    storageBucket: 'SEU_BUCKET.appspot.com',
    measurementId: 'SEU_MEASUREMENT_ID',
  );

  // Configuração para Windows
  static const FirebaseOptions windows = FirebaseOptions(
    apiKey: 'SUA_CHAVE_DE_API_WEB',
    appId: '1:SEU_APP_ID:web:SEU_ID_WEB',
    messagingSenderId: 'SEU_SENDER_ID',
    projectId: 'SEU_PROJETO_ID',
    authDomain: 'SEU_DOMINIO.firebaseapp.com',
    storageBucket: 'SEU_BUCKET.appspot.com',
    measurementId: 'SEU_MEASUREMENT_ID',
  );
}
