import 'package:controlese/firebase_options.dart';
import 'package:controlese/view/auth_service.dart';
import 'package:controlese/view/create_account.dart';
import 'package:controlese/view/finance_page.dart';
import 'package:controlese/view/login_screen.dart';
import 'package:controlese/view/welcome_page.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart'; // Corrigido para usar todos os recursos do GetX

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);

  Get.put(AuthService()); // <-- Registra o AuthService no GetX

  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return GetMaterialApp(
      debugShowCheckedModeBanner: false,

      // <-- Corrigido para GetMaterialApp
      title: 'CONTROLE-\$E',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color.fromARGB(255, 43, 151, 21),
        ),
      ),
      initialRoute: '/',
      routes: {
        '/': (context) => FinanceHomePage(),
        '/login': (context) => LoginScreen(),
        '/create': (context) => CreateAccountPage(),
      },
    );
  }
}
